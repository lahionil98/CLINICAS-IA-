document.addEventListener("DOMContentLoaded",()=>{
const form=document.getElementById("chat-form");
const input=document.getElementById("chat-input");
const msgs=document.getElementById("chat-messages");

form.addEventListener("submit",async(e)=>{
 e.preventDefault();
 const text=input.value.trim();
 if(!text)return;
 add("user",text);
 input.value="";
 add("bot","Pensando...");

 const res=await fetch("/.netlify/functions/chatgpt",{
   method:"POST",
   headers:{"Content-Type":"application/json"},
   body:JSON.stringify({message:text})
 });
 const data=await res.json();
 replaceLastBot(data.reply||"Error.");
});

function add(type,txt){
 const d=document.createElement("div");
 d.className="message "+type;
 d.textContent=txt;
 msgs.appendChild(d);
 msgs.scrollTop=msgs.scrollHeight;
}

function replaceLastBot(txt){
 const bots=[...msgs.querySelectorAll(".bot")];
 const last=bots[bots.length-1];
 if(last) last.textContent=txt;
}
});
